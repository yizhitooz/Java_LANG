public class Example9_21{
    public static void main(String args[]){
        TreeWin win = new TreeWin(); 
    } 
}