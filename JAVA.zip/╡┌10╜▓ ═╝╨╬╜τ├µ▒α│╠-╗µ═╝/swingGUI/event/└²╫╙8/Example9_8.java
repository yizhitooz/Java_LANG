public class Example9_8 {
   public static void main(String args[]) {
      WindowOperation win=new WindowOperation();
      win.setBounds(100,100,390,360);
      win.setTitle("�򵥼�����");
   }
}
