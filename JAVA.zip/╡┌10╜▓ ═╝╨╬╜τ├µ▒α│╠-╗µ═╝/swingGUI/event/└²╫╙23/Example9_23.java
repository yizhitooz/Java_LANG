public class Example9_23 {
   public static void main(String args[]){
        new  BindButtonWindow();
   }
}