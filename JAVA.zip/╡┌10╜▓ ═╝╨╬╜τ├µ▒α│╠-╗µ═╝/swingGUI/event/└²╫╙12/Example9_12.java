public class Example9_12 {
   public static void main(String args[]) {
      Win win=new Win();
      win.setTitle("�������к�");
      win.setBounds(10,10,460,360);
   }
}
