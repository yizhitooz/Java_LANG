package Test;

public class Main
{
    public static void main(String[] args)
    {
        MyJFrame myJFrame = new MyJFrame("ע���¼����", 300, 200);
    }
}