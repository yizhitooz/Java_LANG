package step1extention;
public abstract class People {
    protected double weight,height;
    public void speakHello() {
        System.out.println("yayayaya");
    }
    public abstract void averageHeight();
    public abstract void averageWeight();
}
