package employeeinfo;
/*
 * ʵ����
 */
//import java.util.Date;


//String ID,String name,String born,double salary,String email
public class Application
{

    public static void main(String[] args)
    {
        // TODO Auto-generated method stub
        MainWindow mw = new MainWindow();

        //Operatefile.showUserList();

        System.out.println("Application end");
		
		/*�����ļ���д
		Employee em1=new Employee("Jan","2012",500,"lyh@qq.com");
		Employee em2=new Employee("Jan","2012",500,"lyh@qq.com");
		Employee em3=new Employee("Jan","2012",500,"lyh@qq.com");
		//System.out.println(em.checkEmail("q@q.com"));
		//em.showEmployee();
		//Operatefile.appendEm(em1);		
		//Operatefile.appendEm(em2);
		//Operatefile.appendEm(em3);
		
		Operatefile.showUserList();
		*/
        //System.out.println("������"+Employee.persons);


    }

}

