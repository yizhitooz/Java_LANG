package step5;

public class Test
{
    /********** Begin **********/
    static String name = "������";

    static
    {
        System.out.println("hello educoder");
    }

    public static void main(String[] args)
    {
        System.out.println("�ҽ�" + name);
        study();
    }

    public static void study()
    {
        System.out.println("��ϲ����educoder��ѧϰjava");
    }
    /********** End **********/
}
