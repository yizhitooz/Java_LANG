package step1;

public class HelloWorld {
    public static void main(String[] args)
    {

        /*****start*****/
        int i = 1;
        while (i <= 6)
        {
            System.out.println("����" + i + "�����Գ�");
            i++;
            /*****end*****/

        }
    }
}
