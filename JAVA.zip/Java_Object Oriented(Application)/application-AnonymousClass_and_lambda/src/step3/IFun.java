package step3;

public interface IFun
{
    double fun(double x);
}