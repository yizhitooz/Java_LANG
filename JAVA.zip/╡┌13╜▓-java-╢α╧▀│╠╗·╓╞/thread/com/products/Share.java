package com.products;

public class Share {
	  private int contents;
	  public int get(){
	    return contents;
	  }
	  public void put(int value){
	    contents=value;
	  }
	}

