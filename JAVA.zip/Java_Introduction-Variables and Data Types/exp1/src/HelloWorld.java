//package chapter2.step1;

public class HelloWorld{
    public static void main(String[] args)
    {
        /********* Begin *********/
        String web = "www.educoder.net";
        System.out.print(web);
        /********* End *********/
    }
}