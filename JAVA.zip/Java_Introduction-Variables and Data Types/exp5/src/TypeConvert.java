package chapter2;

public class TypeConvert {
    public static void main(String[] args) {
        /********* Begin *********/
        double score=89.3;
        int scoreInt=(int)score;
        System.out.println(score);
        System.out.println(scoreInt);

        /********* End *********/
    }
}
