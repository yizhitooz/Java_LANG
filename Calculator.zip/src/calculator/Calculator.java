package calculator;

import java.util.Stack;

public class Calculator {

    // �Ƴ�δʹ�õ�ʵ������
    static String[] operators = new String[] { "-", "+", "*", "/", "(", ")" };
    static Stack<String> digitStack = new Stack<>(); // ʹ�÷���������Ͱ�ȫ��
    static Stack<String> operatorStack = new Stack<>();

    public static void main(String[] args) throws Exception {
        String expression = "1+(3+1)*(3-2)";
        transExpression(expression);
        System.out.println(calculate());
    }

    private static String calculate() throws Exception {
        Stack<String> reversedDigitStack = reverse(digitStack); // ʹ�÷���
        Stack<String> resultStack = new Stack<>();
        while (!reversedDigitStack.isEmpty()) {
            String value = reversedDigitStack.pop();
            if (!isOperator(value)) {
                resultStack.push(value);
            } else {
                String value1 = resultStack.pop();
                String value2 = resultStack.pop();
                double result = cal(value1, value2, value); // ֱ��ʹ��double����
                resultStack.push(String.valueOf(result));
            }
        }
        return resultStack.pop();
    }

    private static Stack<String> reverse(Stack<String> s) {
        Stack<String> result = new Stack<>();
        while (!s.isEmpty()) {
            result.push(s.pop());
        }
        return result;
    }

    private static int getPriority(String operatorA) {
        if (operatorA.equals("+") || operatorA.equals("-")) {
            return 1;
        } else if (operatorA.equals("*") || operatorA.equals("/")) {
            return 2;
        } else if (operatorA.equals("(") || operatorA.equals(")")) {
            return 0;
        }
        return 0;
    }

    private static boolean isOperator(String a) {
        for (String c : operators) {
            if (c.equals(a)) {
                return true;
            }
        }
        return false;
    }

    private static boolean comparePriority(String operatorA, String operatorB) {
        return getPriority(operatorA) >= getPriority(operatorB);
    }

    private static double cal(String a, String b, String operator) {
        double tempValue1 = Double.parseDouble(a);
        double tempValue2 = Double.parseDouble(b);
        if (operator.equals("+")) {
            return tempValue1 + tempValue2;
        }
        if (operator.equals("-")) {
            return tempValue2 - tempValue1;
        }
        if (operator.equals("*")) {
            return tempValue1 * tempValue2;
        }
        if (operator.equals("/")) {
            return tempValue2 / tempValue1;
        }
        return 0D;
    }

    private static void transExpression(String expression) throws Exception {
        for (int i = 0; i < expression.length(); i++) {
            String currentChar = String.valueOf(expression.charAt(i));
            if (isOperator(currentChar)) {
                if (operatorStack.isEmpty()) {
                    operatorStack.push(currentChar);
                } else {
                    if (currentChar.equals(")")) {
                        handleClosingParenthesis();
                    } else if (currentChar.equals("(")) {
                        operatorStack.push(currentChar);
                    } else {
                        handleOperator(currentChar);
                    }
                }
            } else {
                digitStack.push(currentChar);
            }
        }

        while (!operatorStack.isEmpty()) {
            digitStack.push(operatorStack.pop());
        }

        // �Ƴ�δ�ṩ��display����
    }

    private static void handleClosingParenthesis() {
        String operator = operatorStack.pop();
        while (operator != null && !operator.equals("(")) {
            digitStack.push(operator);
            if (operatorStack.isEmpty())
                break;
            operator = operatorStack.pop();
        }
    }

    private static void handleOperator(String currentOperator) {
        String operator = operatorStack.peek();
        while (operator != null) {
            if (comparePriority(currentOperator, operator)) {
                operatorStack.push(currentOperator);
                break;
            } else {
                operator = operatorStack.pop();
                digitStack.push(operator);
                operator = operatorStack.peek();
                if (operator == null) {
                    operatorStack.push(currentOperator);
                    break;
                }
            }
        }
    }
}
